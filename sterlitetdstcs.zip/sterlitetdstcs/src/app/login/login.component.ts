import { Component, OnInit, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { HeroService } from '../hero.service';

declare var $: any;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  vendorInput: any;
  data: any = {
    user: 'abhineet',
    pass: 'abhineet',
  };
  constructor(
    private renderer: Renderer2,
    private router: Router,
    private hs: HeroService
  ) {}
  ngOnInit(): void {
    debugger;
    const script = this.renderer.createElement('script');
    script.src = './assets/loginCaptcha.js';
    script.defer = true; // Optional, if you want to defer loading
    
    this.renderer.appendChild(document.body, script);
    // this.callingService();
  }



  title = 'sampleDesignLogin';

  login() {
    // $.cordys.authentication.sso
    //   .authenticate(this.data.user, this.data.pass)
    //   .done((resp: any) => {
    //     console.log('Done');
    //   });
    this.callingService();
  }
  changePage() {
    this.router.navigate(['/search']);
  }

  detectChange() {
    console.log('records=>', this.vendorInput);
    // this.router.navigate()
  }

  // Function to generate OTP
  generateOTP() {
    // Declare a digits variable
    // which stores all digits
    $('#exampleModal').modal('show');
    let digits = '0123456789';
    let OTP = '';
    for (let i = 0; i < 6; i++) {
      OTP += digits[Math.floor(Math.random() * 10)];
    }
    console.log('OTP-->', OTP);
    console.log('vendorInput', this.vendorInput);

    return OTP;
  }

  callingService() {
    this.hs
      .ajax('BAPI_VENDOR_GETDETAIL', 'http://schemas.cordys.com/default', {
        VENDORNO: this.vendorInput,
      })
      .then((resp: any) => {
        debugger;
        if (resp.GENERALDETAIL.VENDOR != '') {
          let userMail = resp.GENERALDETAIL.VENDOR;
          console.log(userMail);
          localStorage.setItem('userMail', userMail);
          console.log('vendor Input', this.vendorInput);
          this.generateOTP();

        } else {
          alert('vendor is wrong');
        }

        // localStorage.setItem('LoggedInUser',that.usename.UserName)
      });
  }
}
